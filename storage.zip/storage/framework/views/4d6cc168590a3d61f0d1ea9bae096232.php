<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-bold">
            <i class="fas fa-map me-2"></i>Détails du site : <?php echo e($site->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid py-4">
        <div class="row g-4 flex-column-reverse flex-lg-row">

            
            <div class="<?php echo e($site->latitude && $site->longitude ? 'col-12 col-lg-7' : 'col-12'); ?>">
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Informations principales</h5>
                        <div class="row">
                            <div class="col-12 col-md-6"><p><strong>Localisation :</strong> <?php echo e($site->location); ?></p></div>
                            <div class="col-12 col-md-6"><p><strong>Superficie :</strong> <?php echo e($site->total_area ?? '-'); ?> m²</p></div>
                            <div class="col-12 col-md-6"><p><strong>Prix m² :</strong> <?php echo e(number_format($site->base_price_per_sqm, 0, ',', ' ')); ?> FCFA</p></div>
                            <div class="col-12 col-md-6"><p><strong>Frais de réservation :</strong> <?php echo e(number_format($site->reservation_fee, 0, ',', ' ')); ?> FCFA</p></div>
                            <div class="col-12 col-md-6"><p><strong>Frais d’adhésion :</strong> <?php echo e(number_format($site->membership_fee, 0, ',', ' ')); ?> FCFA</p></div>
                            <div class="col-12 col-md-6"><p><strong>Plan de paiement :</strong> <?php echo e(strtoupper(str_replace('_', ' ', $site->payment_plan))); ?></p></div>
                        </div>
                        <p><strong>Description :</strong><br><?php echo e($site->description ?? '-'); ?></p>
                    </div>
                </div>

                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Statistiques</h5>
                        <div class="row">
                            <div class="col-12 col-md-6"><p>Lots totaux : <?php echo e($stats['total_lots']); ?></p></div>
                            <div class="col-12 col-md-6"><p>Disponibles : <?php echo e($stats['available_lots']); ?></p></div>
                            <div class="col-12 col-md-6"><p>Réservés : <?php echo e($stats['reserved_lots']); ?></p></div>
                            <div class="col-12 col-md-6"><p>Vendus : <?php echo e($stats['sold_lots']); ?></p></div>
                            <div class="col-12 col-md-6"><p>Prospects intéressés : <?php echo e($stats['total_prospects']); ?></p></div>
                            <div class="col-12 col-md-6"><p>Revenus générés : <?php echo e(number_format($stats['total_revenue'], 0, ',', ' ')); ?> FCFA</p></div>
                        </div>
                    </div>
                </div>

                
                <?php if($site->image_url): ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Plan du lotissement</h5>
                        <?php if($isPdf): ?>
                            <iframe src="<?php echo e(asset('storage/' . $site->image_url)); ?>" width="100%" height="500px" style="border: none;"></iframe>
                        <?php else: ?>
                            <img 
                                src="<?php echo e(asset('storage/' . $site->image_url)); ?>" 
                                alt="Plan du lotissement" 
                                style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 0 8px rgba(0,0,0,0.2);"
                            >
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <a href="<?php echo e(route('sites.edit', $site)); ?>" class="btn btn-warning mb-4">Modifier le site</a>
            </div>

            
            <?php if($site->latitude && $site->longitude): ?>
            <div class="col-12 col-lg-5">
                <div class="card shadow-sm h-100">
                    <div class="card-body d-flex flex-column" style="min-height: 350px;">
                        <h5 class="card-title">Carte de localisation</h5>
                        <div id="map" class="rounded shadow-sm flex-grow-1" style="height: 300px; width: 100%;"></div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>

    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <?php if($site->latitude && $site->longitude): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const map = L.map('map', {
                    center: [<?php echo e($site->latitude); ?>, <?php echo e($site->longitude); ?>],
                    zoom: 15,
                    scrollWheelZoom: false,
                });

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 19,
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                }).addTo(map);

                L.marker([<?php echo e($site->latitude); ?>, <?php echo e($site->longitude); ?>])
                    .addTo(map)
                    .bindPopup("<b><?php echo e(addslashes($site->name)); ?></b>")
                    .openPopup();
            });
        </script>
        <?php endif; ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/sites/show.blade.php ENDPATH**/ ?>