<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h5 fw-bold">Réservation d’un lot pour <?php echo e($prospect->full_name); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <label for="searchLot" class="form-label fw-bold">Rechercher un lot</label>
                <input type="text" id="searchLot" class="form-control" placeholder="Numéro de lot, site...">
            </div>
            <div class="col-md-2 d-flex align-items-end mb-3">
                <button id="clearFilters" class="btn btn-secondary w-100">Réinitialiser</button>
            </div>
        </div>

        <?php if($availableLots->count()): ?>
            <form method="POST" action="<?php echo e(route('reservations.store', $prospect)); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-3" id="lotsGrid">
                    <?php $__currentLoopData = $availableLots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-lg-3 col-6 lot-item" 
                             data-number="<?php echo e(strtolower($lot->lot_number)); ?>" 
                             data-site="<?php echo e(strtolower($lot->site->name)); ?>">
                            <label class="card h-100 lot-card p-3 shadow-sm d-block" style="cursor:pointer;">
                                <input type="radio" name="lot_id" value="<?php echo e($lot->id); ?>" class="form-check-input me-2">
                                <div>
                                    <div class="d-flex justify-content-between align-items-start mb-1">
                                        <strong>Lot <?php echo e($lot->lot_number); ?></strong>
                                        <?php if($lot->position === 'angle'): ?>
                                            <i class="fas fa-crown text-warning" title="Lot en angle"></i>
                                        <?php elseif($lot->position === 'facade'): ?>
                                            <i class="fas fa-star text-info" title="Lot en façade"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div><small class="text-muted"><?php echo e($lot->area); ?> m²</small></div>
                                    <div class="fw-bold text-primary">
                                        <?php echo e(number_format($lot->final_price, 0, ',', ' ')); ?> FCFA
                                    </div>
                                    <div class="mt-1">
                                        <span class="badge bg-success">Disponible</span>
                                        <span class="badge bg-light text-dark"><?php echo e($lot->site->name); ?></span>
                                    </div>
                                </div>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">Réserver le lot</button>
                    <a href="<?php echo e(route('prospects.show', $prospect)); ?>" class="btn btn-secondary">Annuler</a>
                </div>
            </form>
        <?php else: ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle me-2"></i>Aucun lot disponible actuellement.
            </div>
        <?php endif; ?>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('searchLot');
            const clearBtn = document.getElementById('clearFilters');
            const lotItems = document.querySelectorAll('.lot-item');

            function filterLots() {
                const search = searchInput.value.toLowerCase();

                lotItems.forEach(item => {
                    const lotNum = item.dataset.number;
                    const siteName = item.dataset.site;

                    const matches = lotNum.includes(search) || siteName.includes(search);
                    item.style.display = matches ? 'block' : 'none';
                });
            }

            searchInput.addEventListener('input', filterLots);
            clearBtn.addEventListener('click', () => {
                searchInput.value = '';
                filterLots();
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/reservations/create.blade.php ENDPATH**/ ?>