<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h5">🧾 Génération d’un contrat - <?php echo e($prospect->full_name); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('contracts.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="client_id" value="<?php echo e($prospect->id); ?>">
            <input type="hidden" name="site_id" value="<?php echo e($prospect->interested_site_id); ?>">
            <input type="hidden" name="lot_id" value="<?php echo e($lot->id); ?>">

            <div class="mb-3">
                <label for="total_amount" class="form-label">Montant total</label>
                <input type="number" name="total_amount" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="payment_duration_months" class="form-label">Durée de paiement (en mois)</label>
                <select name="payment_duration_months" class="form-select" required>
                    <option value="12">12 mois</option>
                    <option value="24">24 mois</option>
                    <option value="36">36 mois</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="start_date" class="form-label">Date de début</label>
                <input type="date" name="start_date" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="terms_and_conditions" class="form-label">Conditions générales</label>
                <textarea name="terms_and_conditions[]" rows="4" class="form-control" placeholder="Écrire les conditions ligne par ligne"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">📄 Générer le contrat</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/contracts/create.blade.php ENDPATH**/ ?>