<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-bold">
            <i class="fas fa-plus me-2"></i>Créer un Nouveau Lot - <?php echo e($site->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <form action="<?php echo e(route('lots.store', ['site' => $site->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <!-- Numéro du lot -->
                        <div class="mb-3">
                            <label for="lot_number" class="form-label">Numéro du lot</label>
                            <input type="text" name="lot_number" id="lot_number" class="form-control" value="<?php echo e(old('lot_number')); ?>" required>
                            <?php $__errorArgs = ['lot_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Superficie -->
                        <div class="mb-3">
                            <label for="area" class="form-label">Superficie (m²)</label>
                            <input type="number" step="0.01" name="area" id="area" class="form-control" value="<?php echo e(old('area')); ?>" required>
                            <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Position -->
                        <div class="mb-3">
                            <label for="position" class="form-label">Position</label>
                            <select name="position" id="position" class="form-select" required>
                                <option value="">-- Choisir --</option>
                                <option value="interieur" <?php echo e(old('position') == 'interieur' ? 'selected' : ''); ?>>Intérieur</option>
                                <option value="facade" <?php echo e(old('position') == 'facade' ? 'selected' : ''); ?>>Façade (+10%)</option>
                                <option value="angle" <?php echo e(old('position') == 'angle' ? 'selected' : ''); ?>>Angle (+10%)</option>
                            </select>
                            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Prix de base -->
                        <div class="mb-3">
                            <label for="base_price" class="form-label">Prix de base (FCFA)</label>
                            <input type="number" step="0.01" name="base_price" id="base_price" class="form-control" value="<?php echo e(old('base_price')); ?>" required>
                            <?php $__errorArgs = ['base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Statut -->
                        <div class="mb-3">
                            <label for="status" class="form-label">Statut du lot</label>
                            <select name="status" id="status" class="form-select" required>
                                <option value="disponible" <?php echo e(old('status') == 'disponible' ? 'selected' : ''); ?>>Disponible</option>
                                <option value="reserve_temporaire" <?php echo e(old('status') == 'reserve_temporaire' ? 'selected' : ''); ?>>Réservation temporaire</option>
                                <option value="reserve" <?php echo e(old('status') == 'reserve' ? 'selected' : ''); ?>>Réservé</option>
                                <option value="vendu" <?php echo e(old('status') == 'vendu' ? 'selected' : ''); ?>>Vendu</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Description -->
                        <div class="mb-3">
                            <label for="description" class="form-label">Description (optionnelle)</label>
                            <textarea name="description" id="description" rows="3" class="form-control"><?php echo e(old('description')); ?></textarea>
                        </div>

                        <div class="d-flex justify-content-end">
                            <a href="<?php echo e(route('sites.show', $site)); ?>" class="btn btn-secondary me-2">Annuler</a>
                            <button type="submit" class="btn btn-primary">Créer le lot</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/lots/create.blade.php ENDPATH**/ ?>