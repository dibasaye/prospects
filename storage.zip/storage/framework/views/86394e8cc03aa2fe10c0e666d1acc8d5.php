<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h5">📄 Liste des Contrats</h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <form method="GET" action="<?php echo e(route('contracts.index')); ?>" class="mb-4 row">
            <div class="col-md-4">
                <input type="text" name="client" value="<?php echo e(request('client')); ?>" class="form-control" placeholder="🔎 Rechercher un client...">
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">-- Statut --</option>
                    <option value="brouillon" <?php echo e(request('status') == 'brouillon' ? 'selected' : ''); ?>>📝 Brouillon</option>
                    <option value="signe" <?php echo e(request('status') == 'signe' ? 'selected' : ''); ?>>✅ Signé</option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-primary" type="submit">Filtrer</button>
                <a href="<?php echo e(route('contracts.index')); ?>" class="btn btn-secondary">Réinitialiser</a>
            </div>
            <div class="col-md-2 text-end">
                <a href="<?php echo e(route('contracts.export')); ?>" class="btn btn-outline-success">
                    📤 Export CSV
                </a>
            </div>
        </form>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Client</th>
                    <th>Lot</th>
                    <th>Durée</th>
                    <th>Montant Total</th>
                    <th>Statut</th>
                    <th>Signature</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($contract->contract_number); ?></td>
                        <td><?php echo e($contract->client->full_name); ?></td>
                         <td><?php echo e(optional($contract->lot)->lot_number ?? '-'); ?></td>

                        <td><?php echo e($contract->payment_duration_months); ?> mois</td>
                        <td><?php echo e(number_format($contract->total_amount, 0, ',', ' ')); ?> F</td>
                        <td>
                            <?php if($contract->status === 'signe'): ?>
                                <span class="badge bg-success">Signé</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Brouillon</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($contract->signed_by_client && $contract->signed_by_agent): ?>
                                <span class="text-success">🖊️ Double Signature</span>
                            <?php elseif($contract->signed_by_client): ?>
                                <span class="text-primary">✔️ Client</span>
                            <?php else: ?>
                                <span class="text-muted">⏳ En attente</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('contracts.show', $contract)); ?>" class="btn btn-sm btn-info">🔍 Voir</a>
                            <a href="<?php echo e(route('contracts.pdf', $contract)); ?>" class="btn btn-sm btn-secondary">📥 PDF</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted">Aucun contrat trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3">
            <?php echo e($contracts->withQueryString()->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/contracts/index.blade.php ENDPATH**/ ?>