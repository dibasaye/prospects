<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Facture - <?php echo e($payment->reference_number); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; }
        .header { text-align: center; margin-bottom: 30px; }
        .section { margin-bottom: 20px; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { border: 1px solid #000; padding: 8px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Facture de Paiement</h1>
        <p>Référence : <?php echo e($payment->reference_number); ?></p>
        <p>Date : <?php echo e($payment->payment_date->format('d/m/Y')); ?></p>
    </div>

    <div class="section">
        <h2>Client</h2>
        <p><?php echo e($payment->client->full_name); ?></p>
        <p>Téléphone : <?php echo e($payment->client->phone); ?></p>
        <p>Email : <?php echo e($payment->client->email ?? 'N/A'); ?></p>
    </div>

    <div class="section">
        <h2>Détails du paiement</h2>
        <table class="table">
            <tr>
                <th>Site</th>
                <td><?php echo e($payment->site->name); ?></td>
            </tr>
            <tr>
                <th>Type</th>
                <td><?php echo e(ucfirst($payment->type)); ?></td>
            </tr>
            <tr>
                <th>Montant (FCFA)</th>
                <td><?php echo e(number_format($payment->amount, 0, ',', ' ')); ?></td>
            </tr>
            <tr>
                <th>Mode de paiement</th>
                <td><?php echo e(ucfirst(str_replace('_', ' ', $payment->payment_method))); ?></td>
            </tr>
            <tr>
                <th>Description</th>
                <td><?php echo e($payment->description ?? '-'); ?></td>
            </tr>
        </table>
    </div>

    <div class="section">
        <p><em>Motif : "Adhésion / Frais d’ouverture de dossier"</em></p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/payments/invoice.blade.php ENDPATH**/ ?>