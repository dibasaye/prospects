<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h5 mb-0">Gestion des Prospects</h2>
            <a href="<?php echo e(route('prospects.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Nouveau Prospect
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <!-- Filtres -->
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('prospects.index')); ?>" class="row g-3">
                    <div class="col-md-3">
                        <label for="search" class="form-label">Recherche</label>
                        <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>"
                               class="form-control" placeholder="Nom, téléphone, email...">
                    </div>

                    <div class="col-md-3">
                        <label for="status" class="form-label">Statut</label>
                        <select name="status" id="status" class="form-select">
                            <option value="">Tous les statuts</option>
                            <?php $__currentLoopData = ['nouveau','en_relance','interesse','converti','abandonne']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                                    <?php echo e(ucfirst(str_replace('_', ' ', $status))); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <?php if(auth()->user()->isAdmin() || auth()->user()->isManager()): ?>
                        <div class="col-md-3">
                            <label for="assigned_to" class="form-label">Assigné à</label>
                            <select name="assigned_to" id="assigned_to" class="form-select">
                                <option value="">Tous les agents</option>
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($agent->id); ?>" <?php echo e(request('assigned_to') == $agent->id ? 'selected' : ''); ?>>
                                        <?php echo e($agent->full_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-secondary w-100">Filtrer</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Table des prospects -->
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <?php if($prospects->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered mb-0">
                            <thead class="table-light text-center align-middle">
                                <tr>
                                    <th>Prospect</th>
                                    <th>Contact</th>
                                    <th>Statut</th>
                                    <th>Assigné à</th>
                                    <th>Site d'intérêt</th>
                                    <th>Date de contact</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $prospects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prospect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo e($prospect->full_name); ?></strong><br>
                                            <?php if($prospect->budget_min || $prospect->budget_max): ?>
                                                <small class="text-muted">
                                                    Budget : <?php echo e(number_format($prospect->budget_min ?? 0, 0, ',', ' ')); ?> - <?php echo e(number_format($prospect->budget_max ?? 0, 0, ',', ' ')); ?> F
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo e($prospect->phone); ?><br>
                                            <?php if($prospect->email): ?>
                                                <small class="text-muted"><?php echo e($prospect->email); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-info text-dark">
                                                <?php echo e(ucfirst(str_replace('_', ' ', $prospect->status))); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($prospect->assignedTo->full_name ?? 'Non assigné'); ?></td>
                                        <td><?php echo e($prospect->interestedSite->name ?? '-'); ?></td>
                                        <td class="text-center"><?php echo e($prospect->contact_date?->format('d/m/Y') ?? $prospect->created_at->format('d/m/Y')); ?></td>
                                        <td class="text-end">
                                            <div class="d-flex flex-wrap justify-content-end gap-1">
                                                <a href="<?php echo e(route('prospects.show', $prospect)); ?>" class="btn btn-sm btn-outline-primary">Voir</a>
                                                <a href="<?php echo e(route('prospects.edit', $prospect)); ?>" class="btn btn-sm btn-outline-warning">Modifier</a>

                                                <?php if(auth()->user()->isAdmin() || auth()->user()->isManager()): ?>
                                                    <a href="<?php echo e(route('prospects.assign.form', $prospect)); ?>" class="btn btn-sm btn-outline-success">
                                                        Assigner
                                                    </a>
                                                <?php endif; ?>

                                                <?php
                                                    $hasReservation = $prospect->reservations()->where('expires_at', '>', now())->exists();
                                                    $adhesionPaid = $prospect->payments()->byType('adhesion')->exists();
                                                    $reservationPaid = $prospect->payments()->byType('reservation')->exists();
                                                ?>

                                                <?php if(!$hasReservation): ?>
                                                    <a href="<?php echo e(route('reservations.create', $prospect)); ?>" class="btn btn-sm btn-outline-success">📌 Réserver</a>
                                                <?php elseif($hasReservation && !$adhesionPaid): ?>
                                                    <a href="<?php echo e(route('payments.create', $prospect)); ?>" class="btn btn-sm btn-outline-dark">💰 Adhésion</a>
                                                <?php elseif($adhesionPaid && !$reservationPaid): ?>
                                                    <a href="<?php echo e(route('payments.reservation.create', $prospect)); ?>" class="btn btn-sm btn-outline-primary">💰 Réservation</a>
                                               <?php elseif($reservationPaid && !$prospect->contract): ?>
    <a href="<?php echo e(route('contracts.generate', $prospect)); ?>" class="btn btn-sm btn-primary">📝 Contrat</a>
<?php elseif($prospect->contract): ?>
    <a href="<?php echo e(route('contracts.show', $prospect->contract)); ?>" class="btn btn-sm btn-outline-primary">📄 Voir Contrat</a>
<?php endif; ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-3 px-3">
                        <?php echo e($prospects->withQueryString()->links()); ?>

                    </div>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="fas fa-user-slash fa-2x mb-3"></i>
                        <p class="mb-1 fs-5">Aucun prospect trouvé</p>
                        <a href="<?php echo e(route('prospects.create')); ?>" class="btn btn-primary mt-2">Créer un prospect</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/prospects/index.blade.php ENDPATH**/ ?>