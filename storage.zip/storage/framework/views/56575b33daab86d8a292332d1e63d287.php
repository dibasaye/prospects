<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-bold">
            <i class="fas fa-edit me-2"></i>Modifier le Site : <?php echo e($site->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <form method="POST" action="<?php echo e(route('sites.update', $site->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Nom du site</label>
                    <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $site->name)); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="location" class="form-label">Localisation</label>
                    <input type="text" name="location" id="location" class="form-control" value="<?php echo e(old('location', $site->location)); ?>" required>
                </div>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea name="description" id="description" rows="4" class="form-control"><?php echo e(old('description', $site->description)); ?></textarea>
            </div>

            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="total_area" class="form-label">Superficie Totale (m²)</label>
                    <input type="number" name="total_area" id="total_area" class="form-control" value="<?php echo e(old('total_area', $site->total_area)); ?>">
                </div>
                <div class="col-md-4">
                    <label for="base_price_per_sqm" class="form-label">Prix / m²</label>
                    <input type="number" name="base_price_per_sqm" id="base_price_per_sqm" class="form-control" value="<?php echo e(old('base_price_per_sqm', $site->base_price_per_sqm)); ?>" required>
                </div>
                <div class="col-md-4">
                    <label for="payment_plan" class="form-label">Plan de paiement</label>
                    <select name="payment_plan" id="payment_plan" class="form-select" required>
                        <option value="12_months" <?php echo e(old('payment_plan', $site->payment_plan) == '12_months' ? 'selected' : ''); ?>>12 mois</option>
                        <option value="24_months" <?php echo e(old('payment_plan', $site->payment_plan) == '24_months' ? 'selected' : ''); ?>>24 mois</option>
                        <option value="36_months" <?php echo e(old('payment_plan', $site->payment_plan) == '36_months' ? 'selected' : ''); ?>>36 mois</option>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="reservation_fee" class="form-label">Frais de réservation</label>
                    <input type="number" name="reservation_fee" id="reservation_fee" class="form-control" value="<?php echo e(old('reservation_fee', $site->reservation_fee)); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="membership_fee" class="form-label">Frais d'adhésion</label>
                    <input type="number" name="membership_fee" id="membership_fee" class="form-control" value="<?php echo e(old('membership_fee', $site->membership_fee)); ?>" required>
                </div>
            </div>

            
            <div class="row g-3 mt-3">
                <div class="col-md-6">
                    <label class="form-label">Plan de lotissement (PDF/Image)</label>
                    <input type="file" class="form-control" name="image_file" accept=".pdf,image/*">
                </div>
                <div class="col-md-6">
                    <?php if($site->image_url): ?>
                        <?php
                            $isPdf = Str::endsWith($site->image_url, '.pdf');
                        ?>

                        <p class="mt-2 mb-1"><strong>Fichier actuel :</strong></p>
                        <?php if($isPdf): ?>
                            <a href="<?php echo e(asset('storage/' . $site->image_url)); ?>" target="_blank" class="btn btn-outline-primary btn-sm">Voir le PDF</a>
                        <?php else: ?>
                            <img src="<?php echo e(asset('storage/' . $site->image_url)); ?>" alt="Plan du lotissement" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 0 8px rgba(0,0,0,0.2);">
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="d-flex justify-content-end mt-4">
                <a href="<?php echo e(route('sites.show', $site->id)); ?>" class="btn btn-secondary me-2">Annuler</a>
                <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/sites/edit.blade.php ENDPATH**/ ?>