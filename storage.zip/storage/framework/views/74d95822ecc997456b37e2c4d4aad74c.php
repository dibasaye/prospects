<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">
                <i class="fas fa-map me-2"></i>Gestion des Sites
            </h1>
            <?php if(auth()->user()->isAdmin()): ?>
            <a href="<?php echo e(route('sites.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Nouveau Site
            </a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <?php if($sites->count() > 0): ?>
        <div class="row g-4">
            <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 col-xl-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h5 class="card-title mb-0"><?php echo e($site->name); ?></h5>
                            <span class="badge bg-primary"><?php echo e($site->lots->count()); ?> lots</span>
                        </div>

                        <div class="mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-map-marker-alt text-muted me-2"></i>
                                <small class="text-muted"><?php echo e($site->location); ?></small>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-calendar text-muted me-2"></i>
                                <small class="text-muted">Lancé le <?php echo e($site->created_at->format('d/m/Y')); ?></small>
                            </div>
                        </div>

                        <div class="row text-center mb-3">
                            <div class="col-4">
                                <div class="border-end">
                                    <div class="fs-5 fw-bold text-success"><?php echo e($site->availableLots->count()); ?></div>
                                    <small class="text-muted">Disponibles</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="border-end">
                                    <div class="fs-5 fw-bold text-warning"><?php echo e($site->reservedLots->count()); ?></div>
                                    <small class="text-muted">Réservés</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="fs-5 fw-bold text-danger"><?php echo e($site->soldLots->count()); ?></div>
                                <small class="text-muted">Vendus</small>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="row">
                                <div class="col-6">
                                    <small class="text-muted">Frais adhésion</small>
                                    <div class="fw-medium"><?php echo e(number_format($site->membership_fee, 0, ',', ' ')); ?> FCFA</div>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted">Frais réservation</small>
                                    <div class="fw-medium"><?php echo e(number_format($site->reservation_fee, 0, ',', ' ')); ?> FCFA</div>
                                </div>
                            </div>
                        </div>

                        <?php
                            $totalLots = $site->lots->count();
                            $availableLots = $site->availableLots->count();
                            $progress = $totalLots > 0 ? (($totalLots - $availableLots) / $totalLots) * 100 : 0;
                        ?>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <small class="text-muted">Progression des ventes</small>
                                <small class="text-muted"><?php echo e(number_format($progress, 1)); ?>%</small>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar" style="width: <?php echo e($progress); ?>%"></div>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <a href="<?php echo e(route('sites.show', $site)); ?>" class="btn btn-outline-primary">
                                <i class="fas fa-eye me-2"></i>Voir Détails
                            </a>
                            <a href="<?php echo e(route('sites.lots', $site)); ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-th me-2"></i>Gérer Lots
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-4">
            <?php echo e($sites->links()); ?>

        </div>

        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-map fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucun site disponible</h5>
            <p class="text-muted">Commencez par créer votre premier site immobilier</p>
            <?php if(auth()->user()->isAdmin()): ?>
            <a href="<?php echo e(route('sites.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Créer un site
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <?php $__env->startPush('scripts'); ?>
<script>
    function initMaps() {
        <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($site->latitude && $site->longitude): ?>
                const map<?php echo e($site->id); ?> = new google.maps.Map(document.getElementById("map-<?php echo e($site->id); ?>"), {
                    center: { lat: <?php echo e($site->latitude); ?>, lng: <?php echo e($site->longitude); ?> },
                    zoom: 15,
                });
                new google.maps.Marker({
                    position: { lat: <?php echo e($site->latitude); ?>, lng: <?php echo e($site->longitude); ?> },
                    map: map<?php echo e($site->id); ?>,
                    title: "<?php echo e($site->name); ?>",
                });
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    }

    window.initMaps = initMaps;
</script>
<?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/sites/index.blade.php ENDPATH**/ ?>