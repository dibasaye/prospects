<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-bold"><i class="fas fa-plus me-2"></i>Créer un Site</h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <form action="<?php echo e(route('sites.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="form-label">Nom du site</label>
                <input type="text" class="form-control" name="name" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Localisation</label>
                <input type="text" class="form-control" name="location" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea class="form-control" name="description" rows="3"></textarea>
            </div>

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Superficie totale (m²)</label>
                    <input type="number" class="form-control" name="total_area">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Prix/m²</label>
                    <input type="number" class="form-control" name="base_price_per_sqm" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Frais de réservation</label>
                    <input type="number" class="form-control" name="reservation_fee" required>
                </div>
            </div>

            <div class="row g-3 mt-3">
                <div class="col-md-4">
                    <label class="form-label">Frais d'adhésion</label>
                    <input type="number" class="form-control" name="membership_fee" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Nombre total de lots</label>
                    <input type="number" class="form-control" name="total_lots" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Date de lancement</label>
                    <input type="date" class="form-control" name="launch_date">
                </div>
            </div>

            <div class="row g-3 mt-3">
                <div class="col-md-6">
                    <label class="form-label">Latitude</label>
                    <input type="text" class="form-control" name="latitude" placeholder="Ex : 14.6928">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Longitude</label>
                    <input type="text" class="form-control" name="longitude" placeholder="Ex : -17.4467">
                </div>
            </div>

            <div class="row g-3 mt-3">
                <div class="col-md-6">
                    <label class="form-label">Plan de lotissement (PDF/Image)</label>
                    <input type="file" class="form-control" name="image_file" accept=".pdf,image/*">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Plan de paiement</label>
                    <select name="payment_plan" class="form-select" required>
                        <option value="12_months">12 mois</option>
                        <option value="24_months">24 mois</option>
                        <option value="36_months">36 mois</option>
                    </select>
                </div>
            </div>

            <div class="mt-4">
                <button class="btn btn-primary">✅ Enregistrer</button>
                <a href="<?php echo e(route('sites.index')); ?>" class="btn btn-secondary">❌ Annuler</a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/sites/create.blade.php ENDPATH**/ ?>