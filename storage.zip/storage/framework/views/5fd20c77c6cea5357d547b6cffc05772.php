<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 fw-bold">
                    <i class="fas fa-th me-2"></i>Lots - <?php echo e($site->name); ?>

                </h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('sites.index')); ?>">Sites</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('sites.show', $site)); ?>"><?php echo e($site->name); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page">Lots</li>
                    </ol>
                </nav>
            </div>
            <?php if(auth()->user()->isAdmin() || auth()->user()->isManager()): ?>
                <a href="<?php echo e(route('sites.lots.create', $site)); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Nouveau Lot
                </a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row mb-4">
        <!-- FILTRES -->
        <div class="col-md-3 mb-3">
            <label for="statusFilter" class="form-label fw-bold">Filtrer par statut</label>
            <select id="statusFilter" class="form-select" aria-label="Filtrer par statut">
                <option value="">Tous</option>
                <option value="disponible">Disponible</option>
                <option value="reserve">Réservé</option>
                <option value="vendu">Vendu</option>
            </select>
        </div>

        <div class="col-md-3 mb-3">
            <label for="positionFilter" class="form-label fw-bold">Filtrer par position</label>
            <select id="positionFilter" class="form-select" aria-label="Filtrer par position">
                <option value="">Toutes</option>
                <option value="angle">Angle</option>
                <option value="facade">Façade</option>
                <option value="interieur">Intérieur</option>
            </select>
        </div>

        <div class="col-md-4 mb-3">
            <label for="searchLot" class="form-label fw-bold">Rechercher un lot</label>
            <input type="search" id="searchLot" class="form-control" placeholder="Par numéro de lot...">
        </div>

        <div class="col-md-2 d-flex align-items-end mb-3">
            <button id="clearFilters" class="btn btn-secondary w-100">Réinitialiser</button>
        </div>
    </div>

    <?php if($lots->count()): ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="row g-3" id="lotsGrid">
                    <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-2 col-lg-3 col-md-4 col-6 lot-item" 
                             data-status="<?php echo e($lot->status); ?>" 
                             data-position="<?php echo e($lot->position); ?>" 
                             data-number="<?php echo e(strtolower($lot->lot_number)); ?>">
                            <div class="card h-100 lot-card" style="border: 2px solid <?php echo e($lot->status_color); ?> !important;">
                                <div class="card-body p-3 text-center">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h6 class="mb-0"><?php echo e($lot->lot_number); ?></h6>
                                        <?php if($lot->position === 'angle'): ?>
                                            <i class="fas fa-crown text-warning" title="Lot en angle"></i>
                                        <?php elseif($lot->position === 'facade'): ?>
                                            <i class="fas fa-star text-info" title="Lot en façade"></i>
                                        <?php endif; ?>
                                    </div>

                                    <div class="mb-2">
                                        <small class="text-muted"><?php echo e($lot->area); ?> m²</small>
                                    </div>

                                    <div class="mb-2">
                                        <div class="fw-bold text-primary"><?php echo e(number_format($lot->final_price, 0, ',', ' ')); ?> FCFA</div>
                                        <?php if($lot->position !== 'interieur'): ?>
                                            <small class="text-muted">(Base : <?php echo e(number_format($lot->base_price, 0, ',', ' ')); ?> FCFA)</small>
                                        <?php endif; ?>
                                    </div>

                                    <div class="mb-2">
                                        <span class="badge w-100" style="background-color: <?php echo e($lot->status_color); ?>; color: white;">
                                            <?php echo e($lot->status_label); ?>

                                        </span>
                                    </div>

                                    <?php if($lot->reserved_until && $lot->status === 'reserve_temporaire'): ?>
                                        <div class="mb-2">
                                            <small class="text-warning">
                                                <i class="fas fa-clock me-1"></i>
                                                Expire : <?php echo e($lot->reserved_until->format('d/m H:i')); ?>

                                            </small>
                                        </div>
                                    <?php endif; ?>

                                  
<?php if($lot->contract && $lot->contract->client): ?>
    <div class="mb-2">
        <small class="text-muted">
            <i class="fas fa-user me-1"></i>Vendu à <?php echo e($lot->contract->client->full_name); ?>

        </small>
    </div>
<?php elseif($lot->reservation && $lot->reservation->prospect): ?>
    <div class="mb-2">
        <small class="text-muted">
            <i class="fas fa-user me-1"></i>
            Réservé par <?php echo e($lot->reservation->prospect->first_name); ?> <?php echo e($lot->reservation->prospect->last_name); ?>

        </small>
        <?php if($lot->reservation->expires_at): ?>
            <br>
            <small class="text-warning">
                <i class="fas fa-clock me-1"></i>
                Expire le <?php echo e($lot->reservation->expires_at->format('d/m/Y H:i')); ?>

            </small>
        <?php endif; ?>
    </div>
<?php endif; ?>

                                    <div class="d-grid gap-1">
                                        
                                        <?php if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin())): ?>
                                            <?php if($lot->status === 'disponible'): ?>
                                                <button class="btn btn-sm btn-success reserve-lot-btn" 
                                                        data-lot-id="<?php echo e($lot->id); ?>" 
                                                        data-site-id="<?php echo e($site->id); ?>"
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#reserveLotModal">
                                                    <i class="fas fa-lock me-1"></i>Réserver
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        
                                        <?php if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isManager())): ?>
                                            <?php if($lot->status === 'reserve'): ?>
                                                <button class="btn btn-sm btn-warning release-lot-btn" 
                                                        data-lot-id="<?php echo e($lot->id); ?>" 
                                                        data-site-id="<?php echo e($site->id); ?>">
                                                    <i class="fas fa-unlock me-1"></i>Libérer
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-home fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucun lot créé</h5>
            <p class="text-muted">Commencez par créer les lots de ce site</p>
            <?php if(auth()->user()->isAdmin() || auth()->user()->isManager()): ?>
                <a href="<?php echo e(route('sites.lots.create', $site)); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Créer un lot
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    
    <?php if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin())): ?>
        <div class="modal fade" id="reserveLotModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <form id="reserveLotForm" method="POST" action="">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Réserver un Lot</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                            <label for="prospectSelect" class="form-label">Sélectionnez un prospect :</label>
                            <select id="prospectSelect" name="client_id" class="form-select" required>
                                <option value="">Choisir un prospect...</option>
                                <?php $__currentLoopData = $prospects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prospect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($prospect->id); ?>">
                                        <?php echo e($prospect->first_name); ?> <?php echo e($prospect->last_name); ?> - <?php echo e($prospect->phone); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-primary">Réserver</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Éléments filtres
                const statusFilter = document.getElementById('statusFilter');
                const positionFilter = document.getElementById('positionFilter');
                const searchLot = document.getElementById('searchLot');
                const clearFilters = document.getElementById('clearFilters');
                const lotItems = document.querySelectorAll('.lot-item');

                function filterLots() {
                    const statusValue = statusFilter.value;
                    const positionValue = positionFilter.value;
                    const searchValue = searchLot.value.toLowerCase();

                    lotItems.forEach(item => {
                        const status = item.dataset.status;
                        const position = item.dataset.position;
                        const number = item.dataset.number.toLowerCase();

                        const statusMatch = !statusValue || status === statusValue;
                        const positionMatch = !positionValue || position === positionValue;
                        const searchMatch = !searchValue || number.includes(searchValue);

                        item.style.display = (statusMatch && positionMatch && searchMatch) ? 'block' : 'none';
                    });
                }

                statusFilter.addEventListener('change', filterLots);
                positionFilter.addEventListener('change', filterLots);
                searchLot.addEventListener('input', filterLots);
                clearFilters.addEventListener('click', () => {
                    statusFilter.value = '';
                    positionFilter.value = '';
                    searchLot.value = '';
                    filterLots();
                });

                // Gérer bouton Réserver
                <?php if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin())): ?>
                    const reserveLotBtns = document.querySelectorAll('.reserve-lot-btn');
                    const prospectSelect = document.getElementById('prospectSelect');
                    const reserveLotForm = document.getElementById('reserveLotForm');

                    reserveLotBtns.forEach(btn => {
                        btn.addEventListener('click', () => {
                            const lotId = btn.dataset.lotId;
                            const siteId = btn.dataset.siteId;
                            reserveLotForm.action = `/sites/${siteId}/lots/${lotId}/reserve`;
                        });
                    });
                <?php endif; ?>

                // Gérer bouton Libérer
                <?php if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isManager())): ?>
                    const releaseLotBtns = document.querySelectorAll('.release-lot-btn');
                    releaseLotBtns.forEach(btn => {
                        btn.addEventListener('click', () => {
                            if (confirm('Êtes-vous sûr de vouloir libérer ce lot ?')) {
                                const form = document.createElement('form');
                                form.method = 'POST';
                                const siteId = btn.dataset.siteId;
                                const lotId = btn.dataset.lotId;
                                form.action = `/sites/${siteId}/lots/${lotId}/release`;
                                form.innerHTML = `<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">`;
                                document.body.appendChild(form);
                                form.submit();
                            }
                        });
                    });
                <?php endif; ?>
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/sites/lots.blade.php ENDPATH**/ ?>