<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h5">Contrat #<?php echo e($contract->contract_number); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <div class="card mb-4">
            <div class="card-body">
                <h5>Client : <?php echo e($contract->client->full_name); ?></h5>
                <p><strong>Site :</strong> <?php echo e($contract->site->name); ?></p>
                <p><strong>Lot :</strong> <?php echo e($contract->lot->lot_number ?? '-'); ?></p>
                <p><strong>Montant total :</strong> <?php echo e(number_format($contract->total_amount, 0, ',', ' ')); ?> FCFA</p>
                <p><strong>Montant payé :</strong> <?php echo e(number_format($contract->paid_amount, 0, ',', ' ')); ?> FCFA</p>
                <p><strong>Reste à payer :</strong> <?php echo e(number_format($contract->remaining_amount, 0, ',', ' ')); ?> FCFA</p>
                <p><strong>Durée :</strong> <?php echo e($contract->payment_duration_months); ?> mois</p>
                <p><strong>Début :</strong> <?php echo e($contract->start_date->format('d/m/Y')); ?></p>
                <p><strong>Fin :</strong> <?php echo e($contract->end_date->format('d/m/Y')); ?></p>
                <p><strong>Statut :</strong> 
                    <span class="badge bg-secondary text-capitalize">
                        <?php echo e($contract->status); ?>

                    </span>
                </p>
            </div>
        </div>

        <div class="mb-4">
            <a href="<?php echo e(route('contracts.pdf', $contract)); ?>" class="btn btn-outline-primary">📄 Télécharger en PDF</a>
        </div>

        <?php if($contract->status !== 'signe'): ?>
            <div class="card">
                <div class="card-header">Importer contrat signé (PDF)</div>
                <div class="card-body">
                    <form action="<?php echo e(route('contracts.uploadSigned', $contract)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="signed_file" class="form-label">Fichier PDF signé :</label>
                            <input type="file" name="signed_file" class="form-control" accept="application/pdf" required>
                        </div>
                        <button class="btn btn-success">📎 Importer</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-success mt-4">
                ✅ Contrat signé le <?php echo e($contract->signature_date->format('d/m/Y')); ?>

            </div>
        <?php endif; ?>

        <?php if($contract->paymentSchedules->count()): ?>
            <h4 class="mt-5">📅 Échéancier de Paiement</h4>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Montant</th>
                        <th>Date d’échéance</th>
                        <th>Status</th>
                        <th>Date de paiement</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contract->paymentSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($schedule->installment_number); ?></td>
                            <td><?php echo e(number_format($schedule->amount, 0, ',', ' ')); ?> FCFA</td>
                            <td><?php echo e($schedule->due_date->format('d/m/Y')); ?></td>
                            <td>
                                <?php if($schedule->is_paid): ?>
                                    <span class="text-success">✅ Payé</span>
                                <?php elseif($schedule->due_date->isPast()): ?>
                                    <span class="text-danger">❌ En retard</span>
                                <?php else: ?>
                                    <span class="text-warning">⏳ À venir</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($schedule->paid_date ? $schedule->paid_date->format('d/m/Y') : '-'); ?></td>

                            <td>
    <?php if(!$schedule->is_paid): ?>
        <button class="btn btn-sm btn-primary pay-btn" 
                data-schedule-id="<?php echo e($schedule->id); ?>" 
                data-amount="<?php echo e($schedule->amount); ?>"
                data-bs-toggle="modal" 
                data-bs-target="#payModal">
            💵 Verser
        </button>
    <?php else: ?>
        <a href="<?php echo e(route('schedules.receipt', $schedule)); ?>" class="btn btn-sm btn-outline-secondary">
            📄 Reçu
        </a>
    <?php endif; ?>
</td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Modal de paiement -->
<div class="modal fade" id="payModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" id="payForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirmer le paiement</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <p>Voulez-vous confirmer le versement de <strong id="modalAmount">...</strong> FCFA ?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-success">Confirmer</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const payButtons = document.querySelectorAll('.pay-btn');
    const payForm = document.getElementById('payForm');
    const modalAmount = document.getElementById('modalAmount');

    payButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.scheduleId;
            const amount = btn.dataset.amount;

            modalAmount.textContent = new Intl.NumberFormat('fr-FR').format(amount);
            payForm.action = `/payment-schedules/${id}/pay`;
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/contracts/show.blade.php ENDPATH**/ ?>