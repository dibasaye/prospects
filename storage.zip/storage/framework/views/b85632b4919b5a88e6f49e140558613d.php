<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-bold">
            <i class="fas fa-user me-2"></i>Détails du Prospect : <?php echo e($prospect->full_name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $str = app('Illuminate\Support\Str'); ?>

    <div class="container py-4">

        <!-- Informations personnelles -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h5 class="card-title">Informations personnelles</h5>
                <p><strong>Nom :</strong> <?php echo e($prospect->full_name); ?></p>
                <p><strong>Téléphone :</strong> <?php echo e($prospect->phone); ?></p>
                <?php if($prospect->phone_secondary): ?>
                    <p><strong>Téléphone secondaire :</strong> <?php echo e($prospect->phone_secondary); ?></p>
                <?php endif; ?>
                <?php if($prospect->email): ?>
                    <p><strong>Email :</strong> <?php echo e($prospect->email); ?></p>
                <?php endif; ?>
                <?php if($prospect->address): ?>
                    <p><strong>Adresse :</strong> <?php echo e($prospect->address); ?></p>
                <?php endif; ?>
                <?php if($prospect->id_document): ?>
                    <p><strong>Pièce d’identité :</strong></p>
                    <?php if($str::endsWith($prospect->id_document, '.pdf')): ?>
                        <a href="<?php echo e(asset('storage/' . $prospect->id_document)); ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
                            📄 Voir le document PDF
                        </a>
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/' . $prospect->id_document)); ?>" alt="Pièce d’identité" class="img-fluid rounded shadow-sm mb-2" style="max-width: 300px;">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Détails commerciaux -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h5 class="card-title">Détails commerciaux</h5>
                <p><strong>Statut :</strong> 
                    <span class="badge bg-info text-dark"><?php echo e(ucfirst(str_replace('_', ' ', $prospect->status))); ?></span>
                </p>
                <p><strong>Assigné à :</strong> <?php echo e($prospect->assignedTo->full_name ?? 'Non assigné'); ?></p>
                <p><strong>Site d’intérêt :</strong> <?php echo e($prospect->interestedSite->name ?? '-'); ?></p>
                <?php if($prospect->budget_min || $prospect->budget_max): ?>
                    <p><strong>Budget :</strong>
                        <?php echo e(number_format($prospect->budget_min ?? 0, 0, ',', ' ')); ?> - 
                        <?php echo e(number_format($prospect->budget_max ?? 0, 0, ',', ' ')); ?> FCFA
                    </p>
                <?php endif; ?>
                <?php if($prospect->contact_date): ?>
                    <p><strong>Date de contact :</strong> <?php echo e($prospect->contact_date->format('d/m/Y')); ?></p>
                <?php endif; ?>
                <?php if($prospect->notes): ?>
                    <p><strong>Notes :</strong> <?php echo e($prospect->notes); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Paiement d’adhésion -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h5 class="card-title">Paiement d’adhésion</h5>
                <?php if($adhesionPayment = $prospect->payments()->byType('adhesion')->first()): ?>
                    <p><strong>Montant :</strong> <?php echo e(number_format($adhesionPayment->amount, 0, ',', ' ')); ?> FCFA</p>
                    <p><strong>Date :</strong> <?php echo e($adhesionPayment->payment_date->format('d/m/Y')); ?></p>
                    <p><strong>Mode :</strong> <?php echo e(ucfirst($adhesionPayment->payment_method)); ?></p>
                    <p><strong>Référence :</strong> <?php echo e($adhesionPayment->reference_number); ?></p>
                    <p><strong>Motif :</strong> Adhésion / Frais d’ouverture de dossier</p>
                    <a href="<?php echo e(route('payments.invoice', $adhesionPayment)); ?>" class="btn btn-sm btn-outline-secondary" target="_blank">
                        📄 Télécharger la facture
                    </a>
                <?php else: ?>
                    <p class="text-muted">Aucun paiement d’adhésion enregistré.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Paiement de réservation -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h5 class="card-title">Paiement de réservation</h5>
                <?php if($reservationPayment = $prospect->payments()->byType('reservation')->first()): ?>
                    <p><strong>Montant :</strong> <?php echo e(number_format($reservationPayment->amount, 0, ',', ' ')); ?> FCFA</p>
                    <p><strong>Date :</strong> <?php echo e($reservationPayment->payment_date->format('d/m/Y')); ?></p>
                    <p><strong>Mode :</strong> <?php echo e(ucfirst($reservationPayment->payment_method)); ?></p>
                    <p><strong>Référence :</strong> <?php echo e($reservationPayment->reference_number); ?></p>
                    <p><strong>Lot :</strong> <?php echo e($reservationPayment->lot->lot_number ?? '-'); ?></p>
                    <a href="<?php echo e(route('payments.invoice', $reservationPayment)); ?>" class="btn btn-sm btn-outline-secondary" target="_blank">
                        📄 Télécharger la facture
                    </a>
                <?php else: ?>
                    <p class="text-muted">Aucun paiement de réservation enregistré.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Contrat -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h5 class="card-title">Contrat</h5>
                <?php if($prospect->contract): ?>
                    <p><strong>Numéro :</strong> <?php echo e($prospect->contract->contract_number); ?></p>
                    <p><strong>Montant total :</strong> <?php echo e(number_format($prospect->contract->total_amount, 0, ',', ' ')); ?> FCFA</p>
                    <p><strong>Durée (mois) :</strong> <?php echo e($prospect->contract->payment_duration_months); ?></p>
                    <p><strong>Statut :</strong> <?php echo e(ucfirst($prospect->contract->status)); ?></p>
                    <a href="<?php echo e(route('contracts.show', $prospect->contract)); ?>" class="btn btn-sm btn-outline-primary">Voir le contrat</a>
                <?php else: ?>
                    <p class="text-muted">Aucun contrat généré pour ce prospect.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Historique des relances -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="card-title mb-0">Historique des relances</h5>
                    <a href="<?php echo e(route('prospects.followup.form', $prospect)); ?>" class="btn btn-outline-primary btn-sm">
                        + Ajouter une relance
                    </a>
                </div>

                <?php if($prospect->followUps->count()): ?>
                    <ul class="list-group">
                        <?php $__currentLoopData = $prospect->followUps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <strong><?php echo e(ucfirst($followup->type)); ?></strong>
                                <small class="text-muted">par <?php echo e($followup->user->full_name); ?> le <?php echo e($followup->created_at->format('d/m/Y H:i')); ?></small>
                                <div class="mt-1"><?php echo e($followup->notes); ?></div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted">Aucune relance enregistrée.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Actions -->
        <div class="d-flex flex-wrap gap-2 mb-4">
            <?php if(auth()->user()->isAdmin() || auth()->user()->isAgent()): ?>
                <a href="<?php echo e(route('reservations.create', $prospect)); ?>" class="btn btn-outline-success">📌 Réserver un lot</a>
            <?php endif; ?>

            <a href="<?php echo e(route('payments.create', ['prospect' => $prospect->id])); ?>" class="btn btn-success">💰 Paiement d’adhésion</a>

            <a href="<?php echo e(route('payments.reservation.create', $prospect)); ?>" class="btn btn-outline-primary mt-2">
                💰 Paiement de Réservation
            </a>

            <a href="<?php echo e(route('contracts.generate', $prospect)); ?>" class="btn btn-primary">Générer contrat automatiquement</a>

            <a href="<?php echo e(route('prospects.edit', $prospect)); ?>" class="btn btn-warning">✏️ Modifier</a>

            <form action="<?php echo e(route('prospects.destroy', $prospect)); ?>" method="POST" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce prospect ?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger">🗑 Supprimer</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/prospects/show.blade.php ENDPATH**/ ?>