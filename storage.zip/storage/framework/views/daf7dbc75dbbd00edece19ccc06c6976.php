<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="header-title">
            <?php echo e(__('Tableau de bord')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <style>
        /* Reset minimal */
        * {
            box-sizing: border-box;
        }
        body, h2, h3, h4, p, div {
            margin: 0;
            padding: 0;
        }

        /* Header title */
        .header-title {
            font-weight: 600;
            font-size: 1.25rem; /* ~text-xl */
            color: #1f2937; /* gray-800 */
            line-height: 1.25;
            padding-bottom: 1rem;
        }

        /* Container padding */
        .content-padding {
            padding-top: 3rem;
            padding-bottom: 3rem;
        }

        /* Max width container */
        .max-container {
            max-width: 112rem; /* ~7xl = 1120px */
            margin-left: auto;
            margin-right: auto;
            padding-left: 1.5rem;  /* sm:px-6 */
            padding-right: 1.5rem;
        }
        @media(min-width: 1024px) {
            .max-container {
                padding-left: 2rem; /* lg:px-8 */
                padding-right: 2rem;
            }
        }

        /* Grid containers */
        .grid {
            display: grid;
            gap: 1.5rem; /* gap-6 */
        }
        /* 1 col default */
        .grid-cols-1 {
            grid-template-columns: 1fr;
        }
        /* md: 2 columns */
        @media(min-width: 768px) {
            .md-grid-cols-2 {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        /* lg: 4 columns */
        @media(min-width: 1024px) {
            .lg-grid-cols-4 {
                grid-template-columns: repeat(4, 1fr);
            }
            .lg-grid-cols-2 {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        /* Margin bottom */
        .mb-8 {
            margin-bottom: 2rem;
        }

        /* Card */
        .card {
            background: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: box-shadow 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
        }

        .card-body {
            padding: 1rem 1.5rem;
        }

        /* Flex container */
        .flex {
            display: flex;
            align-items: center;
        }
        .items-center {
            align-items: center;
        }
        .justify-between {
            justify-content: space-between;
        }

        /* Flexible grow */
        .flex-1 {
            flex: 1 1 auto;
        }

        /* Text styles */
        .text-lg {
            font-size: 1.125rem;
            line-height: 1.5rem;
        }
        .font-semibold {
            font-weight: 600;
        }
        .font-bold {
            font-weight: 700;
        }
        .text-gray-900 {
            color: #111827;
        }
        .text-gray-500 {
            color: #6b7280;
        }
        .text-primary-600 {
            color: #2563eb; /* blue-600 */
        }
        .text-green-600 {
            color: #16a34a; /* green-600 */
        }
        .text-yellow-600 {
            color: #ca8a04; /* yellow-600 */
        }
        .text-purple-600 {
            color: #7c3aed; /* purple-600 */
        }
        .text-sm {
            font-size: 0.875rem;
        }
        .text-3xl {
            font-size: 1.875rem;
            line-height: 2.25rem;
        }

        /* SVG icon size */
        svg {
            width: 2rem;
            height: 2rem;
        }

        /* Recent lists */
        .space-y-4 > * + * {
            margin-top: 1rem;
        }

        /* Cards for recent activities */
        .card-header {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e5e7eb;
        }
        .card-header h3 {
            font-size: 1.125rem;
            font-weight: 600;
            color: #111827;
        }

        /* Recent item */
        .recent-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f9fafb; /* gray-50 */
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
        }
        .recent-item > div {
            flex: 1;
        }
        .recent-item h4 {
            font-weight: 500;
            color: #111827;
            font-size: 1rem;
            margin-bottom: 0.25rem;
        }
        .recent-item p {
            font-size: 0.875rem;
            color: #6b7280;
            margin: 0;
        }
        .recent-item .text-right {
            text-align: right;
            min-width: 4.5rem;
        }

        /* Status badges */
        .status-active {
            color: #16a34a;
            font-weight: 600;
        }
        .status-pending {
            color: #ca8a04;
            font-weight: 600;
        }
        .status-converted {
            color: #2563eb;
            font-weight: 600;
        }

        /* Link styling for clickable cards */
        a.card {
            text-decoration: none;
            cursor: pointer;
            color: inherit;
            display: flex;
            flex-direction: column;
            transition: box-shadow 0.3s ease;
        }
        a.card:hover {
            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
        }

        /* Utilities */
        .mt-4 {
            margin-top: 1rem;
        }
        .py-12 {
            padding-top: 3rem;
            padding-bottom: 3rem;
        }
        .text-xs {
            font-size: 0.75rem;
            color: #6b7280;
        }
    </style>

    <div class="py-12">
        <div class="max-container content-padding">
            <!-- Statistics Cards -->
            <div class="grid grid-cols-1 md-grid-cols-2 lg-grid-cols-4 mb-8">
                <?php if(auth()->user()->isAdmin() || auth()->user()->isManager()): ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Prospects Total</h3>
                                    <p class="text-3xl font-bold text-primary-600"><?php echo e($stats['total_prospects']); ?></p>
                                    <p class="text-sm text-gray-500">Actifs: <?php echo e($stats['active_prospects']); ?></p>
                                </div>
                                <div class="text-primary-600">
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" >
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Sites Actifs</h3>
                                    <p class="text-3xl font-bold text-green-600"><?php echo e($stats['total_sites']); ?></p>
                                    <p class="text-sm text-gray-500">Lots vendus: <?php echo e($stats['sold_lots']); ?></p>
                                </div>
                                <div class="text-green-600">
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" >
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Paiements</h3>
                                    <p class="text-3xl font-bold text-yellow-600"><?php echo e(number_format($stats['total_payments'], 0, ',', ' ')); ?> F</p>
                                    <p class="text-sm text-gray-500">En attente: <?php echo e($stats['pending_payments']); ?></p>
                                </div>
                                <div class="text-yellow-600">
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" >
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <a href="<?php echo e(route('contracts.index')); ?>" class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Contrats</h3>
                                    <p class="text-3xl font-bold text-purple-600"><?php echo e($stats['total_contracts']); ?></p>
                                    <p class="text-sm text-gray-500">Signés: <?php echo e($stats['signed_contracts']); ?></p>
                                </div>
                                <div class="text-purple-600">
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" >
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Mes Prospects</h3>
                                    <p class="text-3xl font-bold text-primary-600"><?php echo e($stats['my_prospects']); ?></p>
                                    <p class="text-sm text-gray-500">Actifs: <?php echo e($stats['active_prospects']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Convertis</h3>
                                    <p class="text-3xl font-bold text-green-600"><?php echo e($stats['converted_prospects']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Mes Contrats</h3>
                                    <p class="text-3xl font-bold text-purple-600"><?php echo e($stats['my_contracts']); ?></p>
                                    <p class="text-sm text-gray-500">Signés: <?php echo e($stats['signed_contracts']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="flex items-center">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">Commissions</h3>
                                    <p class="text-3xl font-bold text-yellow-600"><?php echo e(number_format($stats['my_payments'], 0, ',', ' ')); ?> F</p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Recent Activities -->
            <div class="grid grid-cols-1 lg-grid-cols-2 gap-6">
                <!-- Recent Prospects -->
                <div class="card">
                    <div class="card-header">
                        <h3>Prospects Récents</h3>
                    </div>
                    <div class="card-body">
                        <?php if($recentProspects->count() > 0): ?>
                            <div class="space-y-4">
                                <?php $__currentLoopData = $recentProspects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prospect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="recent-item">
                                        <div>
                                            <h4><?php echo e($prospect->full_name); ?></h4>
                                            <p><?php echo e($prospect->phone); ?></p>
                                            <?php if($prospect->interestedSite): ?>
                                                <p>Intéressé par: <?php echo e($prospect->interestedSite->name); ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="text-right">
                                            <span class="status-<?php echo e($prospect->status); ?>"><?php echo e(ucfirst($prospect->status)); ?></span>
                                            <p class="text-xs"><?php echo e($prospect->created_at->diffForHumans()); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="mt-4">
                                <a href="<?php echo e(route('prospects.index')); ?>" class="text-primary-600-hover">Voir tous les prospects →</a>
                            </div>
                        <?php else: ?>
                            <p class="text-gray-500" style="text-align:center; padding:1rem 0;">Aucun prospect récent.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Payments -->
                <div class="card">
                    <div class="card-header">
                        <h3>Paiements Récents</h3>
                    </div>
                    <div class="card-body">
                        <?php if($recentPayments->count() > 0): ?>
                            <div class="space-y-4">
                                <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="recent-item">
                                        <div>
                                            <h4><?php echo e($payment->client->full_name); ?></h4>
                                            <p><?php echo e($payment->site->name); ?></p>
                                            <p><?php echo e(ucfirst($payment->type)); ?></p>
                                        </div>
                                        <div class="text-right">
                                            <p class="font-medium text-green-600"><?php echo e(number_format($payment->amount, 0, ',', ' ')); ?> F</p>
                                            <p class="text-xs"><?php echo e($payment->payment_date->format('d/m/Y')); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <p class="text-gray-500" style="text-align:center; padding:1rem 0;">Aucun paiement récent.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/dashboard.blade.php ENDPATH**/ ?>