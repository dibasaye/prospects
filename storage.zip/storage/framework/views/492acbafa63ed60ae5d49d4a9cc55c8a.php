<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        h1 { text-align: center; }
        .section { margin-bottom: 20px; }
    </style>
</head>
<body>
    <h1>Contrat de Réservation</h1>

    <div class="section">
        <strong>Numéro :</strong> <?php echo e($contract->contract_number); ?><br>
        <strong>Date :</strong> <?php echo e(now()->format('d/m/Y')); ?><br>
    </div>

    <div class="section">
        <h3>Informations du Client</h3>
        <p>
            <strong>Nom :</strong> <?php echo e($contract->client->full_name); ?><br>
            <strong>Email :</strong> <?php echo e($contract->client->email); ?><br>
            <strong>Téléphone :</strong> <?php echo e($contract->client->phone); ?><br>
        </p>
    </div>

    <div class="section">
        <h3>Détails de la Réservation</h3>
        <p>
            <strong>Site :</strong> <?php echo e($contract->site->name); ?><br>
            <strong>Lot :</strong> <?php echo e($contract->lot->number ?? '-'); ?><br>
            <strong>Montant total :</strong> <?php echo e(number_format($contract->total_amount, 0, ',', ' ')); ?> FCFA<br>
            <strong>Acompte payé :</strong> <?php echo e(number_format($contract->paid_amount, 0, ',', ' ')); ?> FCFA<br>
            <strong>Durée de paiement :</strong> <?php echo e($contract->payment_duration_months); ?> mois<br>
        </p>
    </div>

    <div class="section">
        <h3>Conditions</h3>
        <p>
            Le client s'engage à régler les mensualités selon l’échéancier prévu.<br>
            Le lot sera définitivement attribué à la signature du présent contrat.<br>
            En cas de non-paiement, la réservation pourra être annulée.
        </p>
    </div>

    <div class="section">
        <h3>Signatures</h3>
        <table width="100%">
            <tr>
                <td>
                    <strong>Client</strong><br><br><br>
                    __________________________
                </td>
                <td style="text-align:right;">
                    <strong>Commercial</strong><br><br><br>
                    __________________________
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/contracts/pdf.blade.php ENDPATH**/ ?>