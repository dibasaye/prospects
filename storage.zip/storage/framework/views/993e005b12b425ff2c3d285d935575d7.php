<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2>Assigner le prospect : <?php echo e($prospect->full_name); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <form action="<?php echo e(route('prospects.assign', $prospect)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="commercial_id" class="form-label">Choisir un commercial</label>
                <select name="commercial_id" id="commercial_id" class="form-select" <?php echo e($prospect->assigned_to_id ? 'disabled' : ''); ?> required>
                    <option value="">-- Sélectionner un commercial --</option>
                    <?php $__currentLoopData = $commerciaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commercial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($commercial->id); ?>"
                            <?php echo e($prospect->assigned_to_id == $commercial->id ? 'selected' : ''); ?>>
                            <?php echo e($commercial->full_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary" <?php echo e($prospect->assigned_to_id ? 'disabled' : ''); ?>>Assigner</button>
            <a href="<?php echo e(route('prospects.index')); ?>" class="btn btn-secondary">Annuler</a>

            <?php if($prospect->assigned_to_id): ?>
                <div class="alert alert-info mt-3">
                    Ce prospect est déjà assigné à <strong><?php echo e($prospect->assignedTo->full_name ?? 'un commercial'); ?></strong>.
                </div>
            <?php endif; ?>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/prospects/assign.blade.php ENDPATH**/ ?>