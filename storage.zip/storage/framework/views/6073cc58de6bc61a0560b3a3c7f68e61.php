<?php if (isset($component)) { $__componentOriginalcb8170ac00b272413fe5b25f86fc5e3a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb8170ac00b272413fe5b25f86fc5e3a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* Texte marron */
        label, 
        .form-check-label, 
        a, 
        h5, 
        .list-unstyled li {
            color: #5C4033 !important;
            font-weight: 600;
        }

        /* Lien mot de passe oublié marron avec hover */
        a {
            text-decoration: none;
        }
        a:hover {
            color: #3e2d22;
            text-decoration: underline;
        }

        /* Bouton connexion marron */
        .btn-primary {
            background-color: #5C4033;
            border-color: #5C4033;
            color: white;
            font-weight: 700;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #3e2d22;
            border-color: #3e2d22;
            color: white;
        }

        /* Pour les erreurs */
        .invalid-feedback {
            color: #b00020;
            font-weight: 600;
        }
    </style>

    <!-- Logo centré -->
    <div class="text-center my-4">
        <img src="<?php echo e(asset('images/image.png')); ?>" alt="Logo Yaye Dia" style="height: 100px;">
        <h2 class="mt-3" style="color:#5C4033;">Bienvenue sur Yaye Dia BTP</h2>
    </div>

    <!-- Statut de session -->
    <?php if(session('status')): ?>
        <div class="alert alert-success" style="color:#155724; font-weight:600;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <!-- Formulaire de connexion -->
    <form method="POST" action="<?php echo e(route('login')); ?>" class="card p-4 shadow-sm">
        <?php echo csrf_field(); ?>

        <!-- Email -->
        <div class="mb-3">
            <label for="email" class="form-label">Adresse e-mail</label>
            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Mot de passe -->
        <div class="mb-3">
            <label for="password" class="form-label">Mot de passe</label>
            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   name="password" required autocomplete="current-password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Se souvenir de moi -->
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="remember_me" name="remember">
            <label class="form-check-label" for="remember_me">Se souvenir de moi</label>
        </div>

        <!-- Bouton / mot de passe oublié -->
        <div class="d-flex justify-content-between align-items-center">
            <?php if(Route::has('password.request')): ?>
                <a href="<?php echo e(route('password.request')); ?>">Mot de passe oublié ?</a>
            <?php endif; ?>
            <button type="submit" class="btn btn-primary">Se connecter</button>
        </div>
    </form>

    <!-- Comptes de démonstration -->
    <div class="mt-4 p-3 bg-light border rounded">
        <h5 class="mb-3">Comptes de démonstration :</h5>
        <ul class="list-unstyled small">
            <li><strong>Administrateur :</strong> admin@yayedia.com / admin123</li>
            <li><strong>Responsable :</strong> manager@yayedia.com / manager123</li>
            <li><strong>Commercial :</strong> commercial@yayedia.com / commercial123</li>
        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb8170ac00b272413fe5b25f86fc5e3a)): ?>
<?php $attributes = $__attributesOriginalcb8170ac00b272413fe5b25f86fc5e3a; ?>
<?php unset($__attributesOriginalcb8170ac00b272413fe5b25f86fc5e3a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb8170ac00b272413fe5b25f86fc5e3a)): ?>
<?php $component = $__componentOriginalcb8170ac00b272413fe5b25f86fc5e3a; ?>
<?php unset($__componentOriginalcb8170ac00b272413fe5b25f86fc5e3a); ?>
<?php endif; ?>
<?php /**PATH C:\Users\dell\ProspectTracker\resources\views/auth/login.blade.php ENDPATH**/ ?>